# Achu AI - Deploy Guide (make it a public website)

Achu AI has a small Node.js server (`server.ts`). The server keeps your
Gemini API key secret and calls the AI for you, so the site needs a
Node-capable host. A plain static host (GitHub Pages, Netlify drop) will
NOT work, because `/api/*` routes are required.

## 1. Get a Gemini API key
Go to https://aistudio.google.com/apikey and create a key.

## 2. Pick a host (any one)
- **Render.com** (easy, has a free tier)
- **Railway.app**
- **Google Cloud Run** (uses the included Dockerfile)

## 3. Deploy on Render (simplest)
1. Put this project on GitHub (create a repo, upload the files).
2. On Render: **New > Web Service** > connect the GitHub repo.
3. Settings:
   - **Runtime:** Node
   - **Build Command:** `npm install && npm run build`
   - **Start Command:** `npm start`
4. **Environment** tab, add:
   - `GEMINI_API_KEY` = your key
   - `AI_PROVIDER` = `auto`
5. Click **Create / Deploy**. You get a URL like `https://achu-ai.onrender.com`.

Or, using the Dockerfile: choose **Runtime: Docker** instead, and skip the
build/start commands.

## 4. Test it
- Open `https://YOUR-URL/api/health`. It should show `{"status":"ok",...}`.
- Open `https://YOUR-URL` in your phone browser and ask a question.

## 5. Install on your phone (like an app)
- **Android (Chrome):** open the site > menu (three dots) > **Install app** / **Add to Home screen**.
- **iPhone (Safari):** open the site > Share button > **Add to Home Screen**.

The site must be on HTTPS for install and voice to work. Render/Railway/Cloud Run give HTTPS automatically.

## 6. Run on your laptop first (optional)
```bash
npm install
cp .env.example .env      # then put your GEMINI_API_KEY inside .env
npm run dev               # open http://localhost:3000
```

Production-style test:
```bash
npm install
npm run build
npm start
```

## Notes
- Offline Physics Class works without internet after the first visit (service worker cache).
- Voice answers use `/api/tts-audio`, which calls a Google Translate TTS endpoint.
  If that is blocked or slow, the app falls back to the phone's built-in voice.
- Never put your API key inside the code or in a file you upload publicly.
